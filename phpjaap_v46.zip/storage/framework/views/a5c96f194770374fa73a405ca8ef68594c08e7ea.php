<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    

    <title>JAAP | Reporte General</title>

    
    <style>


      * {
            
            font-family: Arial;
        }

        html {
          margin: 3cm 2.5cm 3cm 2.5cm;
        }

        h1 {
            
        }

        .ticket {
            margin: 2px;
        }

        td,
        th,
        tr,
        .table {
            border-top: 1px solid black;
          /*
            border-collapse: collapse;
            */
            margin: 0 auto;
            height: 5%;
        }

        td.precio {
            text-align: right;
            font-size: 11px;
        }

        td.cantidad {
            font-size: 11px;
        }

        td.producto {
            text-align: center;
        }

        th {
            text-align: center;
        }


        .centrado {
            text-align: center;
            align-content: center;
        }

        .ticket {
            width: 20px;
            max-width: 20px;
        }

        img {
            max-width: inherit;
            width: inherit;
        }

        * {
            margin: 0;
            padding: 0;
        }

        .ticket {
            margin: 0;
            padding: 0;
        }

        .header {
          display: table;
          /*
          width: 100%;
          height: 15%;
          margin-top: -65px;
          */
        }
        .header_logo {
          display: table-cell;
          /*
          text-align: center;
          */
          /*
          margin: 0 0 0 2px;
          border: red solid 1px;
          */
          vertical-align: middle;
        }
        .header_text {
          display: table-cell;
          text-align: center;
          /*
          */
          vertical-align: middle;
          /*
          border: red solid 2px;
          */
          font-size: 16px;
          font-weight: bold;
        }
        .header_text2 {
          /*
          display: table-cell;
          border: red solid 2px;
          */
          /*text-align: left;*/
          vertical-align: middle;
          font-size: 16px;
        }
        .tabla_contactos{
          display: table;
          width: 100%;
        }
        .datos_contactos{
          display: table-cell;
          /*
          border: red solid 1px;
          */
          font-size: 11px;
          font-weight: bold;
          text-align: left;
        }

        
    </style>
    
  </head>

  <body>
    <div class="header">
      <div class="header_logo">
        <!--
        <img src="<?php echo e(asset('img/logo2.jpeg')); ?>" alt="" style="width: 235px;padding-left: 5px;">
        -->
        <img src="img/logo2.jpeg" alt="" style="width: 200px;">
      </div>
      <?php if($institucion): ?>
      <div class="header_text">
        <br>
        <h3>
          <strong><?php echo e($institucion->NOMBREINST); ?></strong><br><br>
        </h3>

        <div class="tabla_contactos">
          <div class="datos_contactos">
            <?php if($institucion->DIRECCION!=null||$institucion->DIRECCION!=''): ?>
            <strong>DIRECCION: <?php echo e($institucion->DIRECCION); ?></strong><br>
            <?php endif; ?>
            <?php if($institucion->TELEFONO!=null||$institucion->TELEFONO!=''): ?>
            <strong>Tlf: <?php echo e($institucion->TELEFONO); ?></strong><br>
            <?php endif; ?>
            <?php if($institucion->CELULAR!=null||$institucion->CELULAR!=''): ?>
            <strong>Cel: <?php echo e($institucion->CELULAR); ?></strong>
            <?php endif; ?>
          </div>
          <div class="datos_contactos">
            <?php if($institucion->RUC!=null||$institucion->RUC!=''): ?>
            <strong style="font-weight: bold!important;">RUC: <?php echo e($institucion->RUC); ?> </strong><br>
            <?php endif; ?>
            <?php if($institucion->EMAIL!=null||$institucion->EMAIL!=''): ?>
            <strong>EMAIL: <?php echo e($institucion->EMAIL); ?></strong>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <?php endif; ?>
    </div>
    <br>
    <h3 style="text-align: center;">REPORTE GENERAL DE COBROS</h3>
    <?php if($numero_meses>1): ?>
      <h4 style="text-align: center;">
        Meses
        <?php echo e($fechainicio->monthName); ?> <?php echo e($fechainicio->year); ?> a <?php echo e($fechafin->monthName); ?> <?php echo e($fechafin->year); ?>

      </h4>
    <?php endif; ?>
    <?php if($numero_meses==1): ?>
      <h4 style="text-align: center;">
        Mes 
        <?php echo e($fechainicio->monthName); ?> <?php echo e($fechainicio->year); ?>

      </h4>
    <?php endif; ?>




    <br><br><br>
    <h4>
      CORRESPONDIENTE A
      <?php if($numero_meses>1): ?>
          <?php echo e($numero_meses); ?> MESES
      <?php endif; ?>
      <?php if($numero_meses==1): ?>
        <?php echo e($numero_meses); ?> MES
      <?php endif; ?>
    </h4>
    <hr>

    <div id="content">
      <div class="ibox-content">
        <br>
        <table class="table">
          <thead>
            <tr>
              <th>DESCRIPCION</th>
              <th>TOTALES</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                Consumo mensual total
              </td>
              <td style="text-align: right">
                <?php echo e($suma_consumo); ?> <small>m3</small>
              </td>
            </tr>
            <tr>
              <td>
                Suma de medida de exceso mensual total
              </td>
              <td style="text-align: right">
                <?php echo e($suma_excedido); ?> <small>m3</small>
              </td>
            </tr>
            <tr>
              <td>
                Suma de subtotal mensual total
              </td>
              <td style="text-align: right;">
                $ <?php echo e(number_format($suma_subtotal, 2, ",", ".")); ?> <small>USD</small>
              </td>
           </tr>
           <tr>
              <td>
                Suma de cobro de excesos mensual total
              </td>
              <td style="text-align: right;">
                $ <?php echo e(number_format($suma_tar_excedido, 2, ",", ".")); ?> <small>USD</small>
              </td>
           </tr>
          </tbody>
          <tfoot>
           <tr>
              <td>
                SUMA TOTAL DE COBRO
              </td>
              <td style="text-align: right;">
                <strong>
                $ <?php echo e(number_format($suma_total, 2, ",", ".")); ?> <small>USD</small>
                </strong>
              </td>
           </tr>
          </tfoot>
          
        </table>
      </div>

    </div>



</body>
</html>

<?php /**PATH D:\mis doc\proyecto 10\phpjaap\resources\views/reportes/contabilidad/reporteObtenerCobroMensual.blade.php ENDPATH**/ ?>