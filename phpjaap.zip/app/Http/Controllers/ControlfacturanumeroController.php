<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ControlfacturanumeroController extends Controller
{
    //
}
