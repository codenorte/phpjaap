<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    

    <title>JAAP | Factura</title>

    
    <style>
        @page  {
            margin: 0cm 0cm;
            font-family: Arial;
        }

        body {
            margin: 3cm 2cm 2cm;
        }


        .header {
          
          width: 100%;
          height: 15%;
          display: table;
          margin-top: -65px;
        }

        .header_logo {
          display: table-cell;
          text-align: center;
          vertical-align: middle;
          /*
          border: red solid 1px;
          */
          margin: 0 0 0 2px;
        }

        .header_text {
          display: table-cell;
          text-align: center;
          /*
          vertical-align: middle;
          border: red solid 2px;
          */
          font-size: 16px;
        }
        .header_text2 {
          display: table-cell;
          text-align: left;
          vertical-align: middle;
          /*
          border: red solid 2px;
          */
          font-size: 16px;
        }

        .datosUsuario {
          
          width: 100%;
          display: table;
        }

        .datosUsuario_text_left {
          display: table-cell;
          /*
          border: red solid 1px;
          */
          margin: 0 0 0 2px;
        }

        .datosUsuario_text {
          padding-left: 50px;
          display: table-cell;
          /*
          border: red solid 2px;
          */
          font-size: 16px;
        }
        .detallefactura{
          font-size: 12px;
        }
        table thead tr th{
          border-bottom: 1px solid;
        }
        table tbody tr td,table thead tr th{
          border-left: 1px solid;
        }
        table tbody tr td:first-child, table thead tr th:first-child{
          border-left: 0px;
        }
        table tr td{
          font-size: 12px;
        }

    </style>
    
  </head>

  <body>
    <div class="header">
      <div class="header_logo">
        <img src="img/logo2.jpeg" alt="" style="width: 235px;">
        <!--
        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" style="width: 100px;padding-left: 5px;">
        -->
      </div>
      <div class="header_text">
        <strong style="color: blue;">JUNTA ADMINISTRADORA DE AGUA DE "TOCAGÓN"</strong>
        <h5>FACTURA MENSUAL</h5>

        <span> telf: 2954222</span> - <span>Cel: 0959095477</span>
        
      </div>
      <div class="header_text2">
        <?php if($factura): ?>
        <h3 style="text-align: center;vertical-align: top;">Nº: <strong><?php echo e($factura->NUMFACTURA); ?></strong> </h3>
        <?php endif; ?>
      </div>
    </div>

    <div class="datosUsuario">
      <?php if($factura): ?>
      <div class="datosUsuario_text">
        <span>CAJA: <?php echo e($factura->USUARIOACTUAL); ?> </span> <br>
        <span>FECHA EMISION: <?php echo e($factura->FECHAEMISION); ?> </span>
      </div>
      <br>
      
      <?php endif; ?>
      <?php if($medidor): ?>
      <div class="datosUsuario_text_left">
        <span>Nro MEDIDOR: <?php echo e($medidor->NUMMEDIDOR); ?></span><br>
        <span>RUC/CI: <?php echo e($medidor->users['RUCCI']); ?></span><br>
        <span>CLIENTE: <?php echo e($medidor->users['NOMBRES']); ?> <?php echo e($medidor->users['APELLIDOS']); ?> </span><br>
        <span>DIRECCION: <?php echo e($medidor->users['DIRECCION']); ?></span><br>
        <span>SECTOR: <?php echo e($medidor->users['SECTOR']); ?></span>
      </div>
      <?php endif; ?>
    </div>
    <hr>

    <div id="content">
      <div class="detallefactura">
        <span>
          <strong>PAGO MESES: <?php echo e($totaldetalle); ?></strong>&nbsp;&nbsp;&nbsp;&nbsp;
        </span>
        <span>
          <strong>CONSUMO: <?php echo e($total_consumo); ?> m3</strong>&nbsp;&nbsp;&nbsp;&nbsp;
        </span>
        <span><strong>Excedido(m3):<?php echo e($total_medida_excedido); ?>m3</strong></span>
        <span><strong>$( <?php echo e($total_tarifa_excedido); ?> )</strong></span>
      </div>


      <div class="ibox-content">
        <table class="table">
          <thead>
            <tr>
              <th>Mes</th>
              <th>Lect. Ant</th>
              <th>Lect. Act</th>
              <th>Consumo</th>
              <th>Exceso</th>
              <th>Subtotal</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $detallefactura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
               <td><?php echo e($det->ANIOMES); ?></td>
               <td><?php echo e($det->MEDIDAANT); ?></td>
               <td><?php echo e($det->MEDIDAACT); ?></td>
               <td><?php echo e($det->CONSUMO); ?></td>
               <td><?php echo e($det->MEDEXCEDIDO); ?></td>
               <td style="text-align: right;"><?php echo e(number_format($det->SUBTOTAL,2)); ?></td>
               <td style="text-align: right;"><?php echo e(number_format($det->TOTAL,2)); ?></td>
             </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($reconexion>0): ?>
              <tr>
                <td>
                  Reconexion
                </td>
                <td colspan="5"></td>
                <td style="text-align: right;">
                  $ <?php echo e(number_format($reconexion, 2)); ?>

                </td>
              </tr>
            <?php endif; ?>
          </tbody>
          <tfoot>
            <tr>
              <td colspan = "5"></td>
              <td><strong>Subtotal:</strong></td>
              <td><strong><?php echo e($factura->SUBTOTAL); ?></strong></td>
            </tr>
            <tr>
              <td colspan = "5"></td>
              <td><strong>Iva:</strong></td>
              <td><strong><?php echo e($factura->IVA); ?></strong></td>
            </tr>
            <tr>
              <td colspan = "5"></td>
              <td><strong>Tar excedido:</strong></td>
              <td><strong><?php echo e($total_tarifa_excedido); ?></strong></td>
            </tr>
            <tr>
              <td colspan = "5"></td>
              <td><strong>TOTAL:</strong></td>
              <td><strong><?php echo e($factura->TOTAL); ?></strong></td>
            </tr>
         </tfoot>
        </table>

      </div>

   </div>



</body>
</html>

<?php /**PATH D:\mis doc\proyecto 10\phpjaap\resources\views/reportes/facturas/verFacturaIdPDF.blade.php ENDPATH**/ ?>