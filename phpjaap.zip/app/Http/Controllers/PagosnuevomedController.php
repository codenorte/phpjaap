<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagosnuevomedController extends Controller
{
    //
}
