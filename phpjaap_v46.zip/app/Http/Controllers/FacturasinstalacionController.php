<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FacturasinstalacionController extends Controller
{
    //
}
